
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ImageSize } from "../types";

// Check if user has an API Key for Pro models (required for Veo/Imagen/Pro Image)
export const ensureProAccess = async () => {
  if (typeof window.aistudio?.hasSelectedApiKey === 'function') {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await window.aistudio.openSelectKey();
      return true; // Assume success after opening dialog
    }
  }
  return true;
};

export const generateDotaWallpaper = async (prompt: string, size: ImageSize) => {
  await ensureProAccess();
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: `Dota 2 cinematic wallpaper style: ${prompt}` }],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
          imageSize: size === ImageSize.K1 ? "1K" : size === ImageSize.K2 ? "2K" : "4K"
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned from Gemini");
  } catch (error: any) {
    if (error?.message?.includes("Requested entity was not found")) {
      await window.aistudio.openSelectKey();
    }
    throw error;
  }
};

export const analyzeWallpaper = async (imageBase64: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { data: imageBase64.split(',')[1], mimeType: 'image/jpeg' } },
        { text: "Analyze this wallpaper. Provide a description, dominant colors, and the 'vibe' in JSON format." }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          description: { type: Type.STRING },
          colors: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          vibe: { type: Type.STRING }
        },
        required: ["description", "colors", "vibe"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const suggestWallpaperDetails = async (imageBase64: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { data: imageBase64.split(',')[1], mimeType: 'image/jpeg' } },
        { text: "Suggest a title, identify the Dota 2 hero, choose a category (Agility, Strength, Intelligence, or Concept), and provide 3 relevant tags in JSON format." }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          hero: { type: Type.STRING },
          category: { type: Type.STRING },
          tags: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          }
        },
        required: ["title", "hero", "category", "tags"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const fastChatResponse = async (message: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-lite-latest',
    contents: [{ parts: [{ text: `You are a Dota 2 expert. Answer concisely: ${message}` }] }],
    config: {
      temperature: 0.7,
      maxOutputTokens: 200
    }
  });
  return response.text;
};
