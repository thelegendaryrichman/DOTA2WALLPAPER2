
import React, { useState, useEffect } from 'react';
import { MOCK_WALLPAPERS, CATEGORIES } from './constants';
import { Wallpaper, Message } from './types';
import WallpaperCard from './components/WallpaperCard';
import AIGenerator from './components/AIGenerator';
import ImageAnalyzer from './components/ImageAnalyzer';
import { fastChatResponse, suggestWallpaperDetails } from './services/geminiService';
import { loadWallpapers, saveWallpapers } from './services/storageService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'gallery' | 'forge' | 'lab'>('gallery');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedWallpaper, setSelectedWallpaper] = useState<Wallpaper | null>(null);
  const [allWallpapers, setAllWallpapers] = useState<Wallpaper[]>(MOCK_WALLPAPERS);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [isInitializing, setIsInitializing] = useState(true);
  
  // Persistence for all wallpapers using IndexedDB (Reliable for large base64 images)
  useEffect(() => {
    const initStorage = async () => {
      try {
        const stored = await loadWallpapers();
        if (stored && stored.length > 0) {
          // Merge logic: ensure MOCK_WALLPAPERS are always present if not already in DB
          const merged = [...stored];
          MOCK_WALLPAPERS.forEach(mw => {
            if (!merged.find(w => w.id === mw.id)) {
              merged.push(mw);
            }
          });
          setAllWallpapers(merged);
        } else {
          // First run: save MOCK_WALLPAPERS to DB
          await saveWallpapers(MOCK_WALLPAPERS);
          setAllWallpapers(MOCK_WALLPAPERS);
        }
      } catch (e) {
        console.error("IndexedDB initialization failed, falling back to mock only", e);
      } finally {
        setIsInitializing(false);
      }
    };
    initStorage();
  }, []);

  // Sync to IndexedDB whenever allWallpapers changes
  useEffect(() => {
    if (!isInitializing) {
      saveWallpapers(allWallpapers);
    }
  }, [allWallpapers, isInitializing]);

  // Persistence for favorited wallpaper IDs (small enough for localStorage)
  useEffect(() => {
    const storedSaved = localStorage.getItem('dw_saved_wallpapers');
    if (storedSaved) {
      try {
        setSavedIds(new Set(JSON.parse(storedSaved)));
      } catch (e) {
        console.error("Failed to parse saved wallpapers");
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('dw_saved_wallpapers', JSON.stringify(Array.from(savedIds)));
  }, [savedIds]);

  // Chat state
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Message[]>([
    { role: 'model', text: 'Ask me anything about Dota 2 mechanics, heroes, or lore!' }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Upload Modal state
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadHero, setUploadHero] = useState('');
  const [uploadCategory, setUploadCategory] = useState<Wallpaper['category']>('Concept');
  const [uploadTags, setUploadTags] = useState('');
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);

  const filteredWallpapers = allWallpapers.filter(wp => {
    if (selectedCategory === 'Saved') return savedIds.has(wp.id);
    return selectedCategory === 'All' || wp.category === selectedCategory;
  });

  const handleSendMessage = async () => {
    if (!chatInput.trim() || isChatLoading) return;
    
    const userMsg: Message = { role: 'user', text: chatInput };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const response = await fastChatResponse(chatInput);
      setChatMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (err) {
      setChatMessages(prev => [...prev, { role: 'model', text: "Error: Could not reach the strategist." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setUploadPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAiSuggest = async () => {
    if (!uploadPreview) return;
    setIsAiSuggesting(true);
    try {
      const details = await suggestWallpaperDetails(uploadPreview);
      setUploadTitle(details.title);
      setUploadHero(details.hero);
      setUploadCategory(details.category as any);
      setUploadTags(details.tags.join(', '));
    } catch (err) {
      console.error(err);
      alert("AI was unable to identify this image. Please fill details manually.");
    } finally {
      setIsAiSuggesting(false);
    }
  };

  const handleSubmitWallpaper = () => {
    if (!uploadPreview || !uploadTitle || !uploadHero) return;

    const newWallpaper: Wallpaper = {
      id: `up-${Date.now()}`,
      title: uploadTitle,
      hero: uploadHero,
      url: uploadPreview,
      category: uploadCategory,
      resolution: 'Uploaded',
      tags: uploadTags.split(',').map(t => t.trim()).filter(Boolean)
    };

    setAllWallpapers([newWallpaper, ...allWallpapers]);
    setIsSubmitModalOpen(false);
    resetUploadForm();
  };

  const handleDeleteWallpaper = (id: string) => {
    setAllWallpapers(prev => prev.filter(wp => wp.id !== id));
    if (savedIds.has(id)) {
      toggleSave(id);
    }
  };

  const toggleSave = (id: string) => {
    setSavedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const resetUploadForm = () => {
    setUploadPreview(null);
    setUploadTitle('');
    setUploadHero('');
    setUploadCategory('Concept');
    setUploadTags('');
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col items-center justify-center">
        <div className="w-16 h-16 border-4 border-red-600/20 border-t-red-600 rounded-full animate-spin mb-4" />
        <p className="text-stone-400 font-bold uppercase tracking-widest animate-pulse">Loading Archives...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 selection:bg-red-500 selection:text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-stone-950/80 backdrop-blur-xl border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center font-black text-xl shadow-lg shadow-red-900/20 cursor-pointer" onClick={() => setActiveTab('gallery')}>
                DW
              </div>
              <span className="font-bold text-xl tracking-tight uppercase cursor-pointer" onClick={() => setActiveTab('gallery')}>Dota<span className="text-red-600">Wallpapers</span></span>
            </div>

            <nav className="hidden md:flex items-center gap-1">
              {[
                { id: 'gallery', label: 'Gallery', icon: '⧉' },
                { id: 'forge', label: 'AI Forge', icon: '◆' },
                { id: 'lab', label: 'Laboratory', icon: '◈' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 ${
                    activeTab === item.id 
                      ? 'bg-stone-800 text-white' 
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span className={activeTab === item.id ? 'text-red-500' : 'text-stone-600'}>{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-3">
             <button 
                onClick={() => setIsSubmitModalOpen(true)}
                className="hidden sm:flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white text-sm font-bold px-5 py-2.5 rounded-full transition-all shadow-lg shadow-red-900/20"
             >
               <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
               </svg>
               Submit
             </button>
             <button 
                onClick={() => setChatOpen(!chatOpen)}
                className="bg-stone-800 hover:bg-stone-700 p-2.5 rounded-full transition-colors relative"
             >
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
               </svg>
               <span className="absolute top-0 right-0 w-3 h-3 bg-red-600 border-2 border-stone-950 rounded-full"></span>
             </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 pb-24">
        {activeTab === 'gallery' && (
          <div className="space-y-8">
            <section className="bg-stone-900/30 border border-stone-800 rounded-3xl p-8 flex flex-col items-center text-center overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-r from-red-600/5 to-transparent pointer-events-none" />
              <h1 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter uppercase italic text-white">Legendary Wallpapers</h1>
              <p className="text-stone-400 max-w-2xl text-lg mb-8">Download high-resolution 4K and 8K wallpapers of your favorite Dota 2 heroes. Curated by the community and generated by AI.</p>
              
              <div className="flex flex-wrap justify-center gap-2">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-6 py-2 rounded-full text-sm font-bold border transition-all flex items-center gap-2 ${
                      selectedCategory === cat 
                        ? 'bg-white border-white text-black shadow-xl' 
                        : 'bg-stone-950/50 border-stone-800 text-stone-400 hover:border-stone-700'
                    }`}
                  >
                    {cat === 'Saved' && <span className={selectedCategory === 'Saved' ? 'text-red-600' : 'text-stone-600'}>♥</span>}
                    {cat}
                  </button>
                ))}
              </div>
            </section>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredWallpapers.map(wp => (
                <WallpaperCard 
                  key={wp.id} 
                  wallpaper={wp} 
                  onClick={setSelectedWallpaper} 
                  onDelete={handleDeleteWallpaper}
                  isSaved={savedIds.has(wp.id)}
                />
              ))}
              {filteredWallpapers.length === 0 && (
                <div className="col-span-full py-20 text-center text-stone-600">
                   <p className="text-xl font-bold">
                    {selectedCategory === 'Saved' ? "You haven't saved any wallpapers yet." : "No wallpapers found in this category."}
                   </p>
                   {selectedCategory !== 'Saved' && (
                    <button onClick={() => setIsSubmitModalOpen(true)} className="mt-4 text-red-500 hover:underline">Be the first to upload one!</button>
                   )}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'forge' && <AIGenerator />}
        
        {activeTab === 'lab' && <ImageAnalyzer />}
      </main>

      {/* Upload/Submit Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-stone-900 border border-stone-800 w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
              <div className="p-6 border-b border-stone-800 flex justify-between items-center bg-stone-900/50">
                 <h2 className="text-xl font-bold uppercase tracking-tight">Submit Wallpaper</h2>
                 <button onClick={() => { setIsSubmitModalOpen(false); resetUploadForm(); }} className="text-stone-500 hover:text-white">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                   </svg>
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                 {/* File Area */}
                 <div 
                    className={`aspect-video rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center relative overflow-hidden ${
                      uploadPreview ? 'border-stone-700' : 'border-stone-800 bg-stone-950/50 hover:border-stone-600'
                    }`}
                 >
                    {uploadPreview ? (
                      <img src={uploadPreview} className="w-full h-full object-cover" alt="Preview" />
                    ) : (
                      <div className="text-center p-8">
                        <div className="w-16 h-16 bg-stone-900 rounded-full flex items-center justify-center mx-auto mb-4 text-stone-500">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                        <p className="text-stone-300 font-bold">Select high-quality image</p>
                        <p className="text-stone-500 text-sm mt-1">PNG, JPG or WebP up to 10MB</p>
                      </div>
                    )}
                    <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileChange} accept="image/*" />
                 </div>

                 {uploadPreview && (
                   <button 
                      onClick={handleAiSuggest}
                      disabled={isAiSuggesting}
                      className="w-full py-2.5 rounded-xl border border-blue-500/30 bg-blue-500/10 text-blue-400 font-bold text-sm flex items-center justify-center gap-2 hover:bg-blue-500/20 transition-colors"
                   >
                     {isAiSuggesting ? (
                       <div className="w-4 h-4 border-2 border-blue-400/20 border-t-blue-400 rounded-full animate-spin" />
                     ) : (
                       <span className="text-lg">✨</span>
                     )}
                     Auto-detect Details with AI
                   </button>
                 )}

                 {/* Form Fields */}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                       <label className="text-xs font-bold uppercase text-stone-500 tracking-wider">Wallpaper Title</label>
                       <input 
                         type="text" 
                         className="w-full bg-stone-950 border border-stone-800 rounded-xl px-4 py-3 text-sm focus:ring-1 focus:ring-red-500 outline-none text-white" 
                         placeholder="e.g. Arcana Vengeful Spirit"
                         value={uploadTitle}
                         onChange={e => setUploadTitle(e.target.value)}
                       />
                    </div>
                    <div className="space-y-1">
                       <label className="text-xs font-bold uppercase text-stone-500 tracking-wider">Hero Name</label>
                       <input 
                         type="text" 
                         className="w-full bg-stone-950 border border-stone-800 rounded-xl px-4 py-3 text-sm focus:ring-1 focus:ring-red-500 outline-none text-white" 
                         placeholder="e.g. Vengeful Spirit"
                         value={uploadHero}
                         onChange={e => setUploadHero(e.target.value)}
                       />
                    </div>
                    <div className="space-y-1">
                       <label className="text-xs font-bold uppercase text-stone-500 tracking-wider">Category</label>
                       <select 
                         className="w-full bg-stone-950 border border-stone-800 rounded-xl px-4 py-3 text-sm focus:ring-1 focus:ring-red-500 outline-none appearance-none text-white"
                         value={uploadCategory}
                         onChange={e => setUploadCategory(e.target.value as any)}
                       >
                         {CATEGORIES.filter(c => c !== 'All' && c !== 'Saved').map(c => <option key={c} value={c}>{c}</option>)}
                       </select>
                    </div>
                    <div className="space-y-1">
                       <label className="text-xs font-bold uppercase text-stone-500 tracking-wider">Tags (comma separated)</label>
                       <input 
                         type="text" 
                         className="w-full bg-stone-950 border border-stone-800 rounded-xl px-4 py-3 text-sm focus:ring-1 focus:ring-red-500 outline-none text-white" 
                         placeholder="e.g. Celestial, Dark, Arcana"
                         value={uploadTags}
                         onChange={e => setUploadTags(e.target.value)}
                       />
                    </div>
                 </div>
              </div>

              <div className="p-6 bg-stone-950/50 border-t border-stone-800">
                 <button 
                    onClick={handleSubmitWallpaper}
                    disabled={!uploadPreview || !uploadTitle || !uploadHero}
                    className="w-full bg-white text-black font-black py-4 rounded-xl uppercase tracking-widest disabled:opacity-30 transition-all hover:bg-stone-200 shadow-xl"
                 >
                   Publish Wallpaper
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Lightbox / Modal */}
      {selectedWallpaper && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4 md:p-12 animate-in fade-in zoom-in duration-300">
          <button 
            onClick={() => setSelectedWallpaper(null)}
            className="absolute top-6 right-6 text-stone-400 hover:text-white p-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="max-w-6xl w-full flex flex-col md:flex-row gap-8 bg-stone-900 border border-stone-800 rounded-3xl overflow-hidden shadow-2xl">
            <div className="flex-1 overflow-hidden flex items-center bg-stone-950">
              <img src={selectedWallpaper.url} alt={selectedWallpaper.title} className="w-full h-auto" />
            </div>
            
            <div className="w-full md:w-80 p-8 flex flex-col justify-between">
              <div>
                <span className="text-red-500 font-bold uppercase tracking-tighter text-sm">{selectedWallpaper.category}</span>
                <h2 className="text-3xl font-black uppercase italic mb-1 text-white">{selectedWallpaper.title}</h2>
                <p className="text-stone-400 mb-6">{selectedWallpaper.hero}</p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-stone-800 flex items-center justify-center text-xl text-white">📏</div>
                    <div>
                      <p className="text-xs text-stone-500 uppercase font-bold">Resolution</p>
                      <p className="font-bold text-white">{selectedWallpaper.resolution}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-stone-800 flex items-center justify-center text-xl text-white">🏷️</div>
                    <div>
                      <p className="text-xs text-stone-500 uppercase font-bold">Tags</p>
                      <p className="text-sm text-stone-300">{selectedWallpaper.tags.join(', ')}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <button 
                  className="w-full bg-white text-black font-black py-4 rounded-xl uppercase tracking-wider hover:bg-stone-200 transition-colors shadow-lg shadow-white/5"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = selectedWallpaper.url;
                    link.download = `${selectedWallpaper.title.replace(' ', '-')}.jpg`;
                    link.click();
                  }}
                >
                  Download HD
                </button>
                <button 
                  onClick={() => toggleSave(selectedWallpaper.id)}
                  className={`w-full py-4 rounded-xl font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                    savedIds.has(selectedWallpaper.id)
                      ? 'bg-red-600/20 border border-red-600 text-red-500 hover:bg-red-600 hover:text-white'
                      : 'bg-stone-800 text-stone-200 hover:bg-stone-700'
                  }`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${savedIds.has(selectedWallpaper.id) ? 'fill-current' : 'fill-none'}`} viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                  {savedIds.has(selectedWallpaper.id) ? 'Saved to Favorites' : 'Save to Favorites'}
                </button>
                <button 
                  onClick={() => {
                    setActiveTab('lab');
                    setSelectedWallpaper(null);
                  }}
                  className="w-full bg-stone-800 text-stone-400 text-sm font-bold py-2 rounded-xl hover:bg-stone-700 transition-colors"
                >
                  Analyze Palette
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Fast Chat */}
      {chatOpen && (
        <div className="fixed bottom-24 right-6 w-80 md:w-96 z-50 bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl flex flex-col h-[500px] animate-in slide-in-from-bottom-4 duration-300">
          <div className="p-4 border-b border-stone-800 flex items-center justify-between bg-stone-800/50 rounded-t-2xl">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <h3 className="font-bold uppercase tracking-tight text-sm text-white">Dota Strategist AI</h3>
            </div>
            <button onClick={() => setChatOpen(false)} className="text-stone-500 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-4 py-2 rounded-2xl text-sm ${
                  msg.role === 'user' ? 'bg-red-600 text-white' : 'bg-stone-800 text-stone-200'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isChatLoading && (
              <div className="flex justify-start">
                <div className="bg-stone-800 px-4 py-2 rounded-2xl flex gap-1 items-center">
                  <div className="w-1.5 h-1.5 bg-stone-500 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-stone-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-1.5 h-1.5 bg-stone-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-stone-800">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Ask about items, builds..."
                className="flex-1 bg-stone-950 border border-stone-800 rounded-xl px-4 py-2 text-sm focus:ring-1 focus:ring-red-500 outline-none text-white"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <button 
                onClick={handleSendMessage}
                disabled={isChatLoading || !chatInput.trim()}
                className="bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white p-2 rounded-xl transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-stone-900 bg-stone-950 py-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-red-600 rounded flex items-center justify-center font-black text-xs">DW</div>
              <span className="font-bold text-sm tracking-tight uppercase">Dota<span className="text-red-600">Wallpapers</span></span>
            </div>
            <p className="text-stone-500 text-xs">Powered by Gemini Nano Banana Pro Intelligence</p>
          </div>
          
          <div className="flex gap-8 text-stone-500 text-sm font-bold uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Submit</a>
            <a href="#" className="hover:text-white transition-colors">API</a>
          </div>

          <p className="text-stone-600 text-xs">© 2025 DotaWallpapers Clone. For training purposes only.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
