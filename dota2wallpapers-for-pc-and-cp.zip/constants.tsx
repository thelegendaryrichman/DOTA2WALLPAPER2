
import { Wallpaper } from './types';

export const MOCK_WALLPAPERS: Wallpaper[] = [
  {
    id: '1',
    title: 'Shadow Fiend Arcana',
    hero: 'Shadow Fiend',
    url: 'https://picsum.photos/id/10/1920/1080',
    category: 'Agility',
    resolution: '1920x1080',
    tags: ['Demonic', 'Fire', 'Soul']
  },
  {
    id: '2',
    title: 'Crystal Maiden Frostfall',
    hero: 'Crystal Maiden',
    url: 'https://picsum.photos/id/11/1920/1080',
    category: 'Intelligence',
    resolution: '3840x2160',
    tags: ['Ice', 'Magic', 'Winter']
  },
  {
    id: '3',
    title: 'Juggernaut Bladefury',
    hero: 'Juggernaut',
    url: 'https://picsum.photos/id/12/1920/1080',
    category: 'Agility',
    resolution: '1920x1080',
    tags: ['Mask', 'Katana', 'Wind']
  },
  {
    id: '4',
    title: 'Pudge Meat Hook',
    hero: 'Pudge',
    url: 'https://picsum.photos/id/13/1920/1080',
    category: 'Strength',
    resolution: '2560x1440',
    tags: ['Hook', 'Gory', 'Undead']
  },
  {
    id: '5',
    title: 'Ancient Apparition',
    hero: 'Ancient Apparition',
    url: 'https://picsum.photos/id/14/1920/1080',
    category: 'Intelligence',
    resolution: '1920x1080',
    tags: ['Ice', 'Cosmic', 'Void']
  },
  {
    id: '6',
    title: 'Roshan Cave',
    hero: 'Roshan',
    url: 'https://picsum.photos/id/15/1920/1080',
    category: 'Concept',
    resolution: '3840x2160',
    tags: ['Cave', 'Beast', 'Lava']
  },
  {
    id: '7',
    title: 'Phantom Assassin',
    hero: 'Phantom Assassin',
    url: 'https://picsum.photos/id/16/1920/1080',
    category: 'Agility',
    resolution: '1920x1080',
    tags: ['Assassin', 'Dagger', 'Blur']
  },
  {
    id: '8',
    title: 'Invoker Spells',
    hero: 'Invoker',
    url: 'https://picsum.photos/id/17/1920/1080',
    category: 'Intelligence',
    resolution: '1920x1080',
    tags: ['Magic', 'Wizard', 'Quas']
  }
];

export const CATEGORIES = ['All', 'Agility', 'Strength', 'Intelligence', 'Concept', 'Saved'];
