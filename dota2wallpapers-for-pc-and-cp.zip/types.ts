
export interface Wallpaper {
  id: string;
  title: string;
  hero: string;
  url: string;
  category: 'Agility' | 'Strength' | 'Intelligence' | 'Concept';
  resolution: string;
  tags: string[];
}

export enum ImageSize {
  K1 = '1K',
  K2 = '2K',
  K4 = '4K'
}

export interface AnalysisResult {
  description: string;
  colors: string[];
  vibe: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
