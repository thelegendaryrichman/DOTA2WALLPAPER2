
import React from 'react';
import { Wallpaper } from '../types';

interface WallpaperCardProps {
  wallpaper: Wallpaper;
  onClick: (wp: Wallpaper) => void;
  onDelete?: (id: string) => void;
  isSaved?: boolean;
}

const WallpaperCard: React.FC<WallpaperCardProps> = ({ wallpaper, onClick, onDelete, isSaved }) => {
  const isUploaded = wallpaper.id.startsWith('up-') || wallpaper.id.startsWith('forge-');

  return (
    <div 
      className="group relative overflow-hidden rounded-xl bg-stone-900 cursor-pointer transition-transform hover:scale-[1.02] shadow-xl"
      onClick={() => onClick(wallpaper)}
    >
      <div className="aspect-video w-full overflow-hidden">
        <img 
          src={wallpaper.url} 
          alt={wallpaper.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
        <h3 className="text-lg font-bold text-white mb-1">{wallpaper.title}</h3>
        <p className="text-stone-300 text-sm mb-2">{wallpaper.hero}</p>
        <div className="flex flex-wrap gap-1">
          {wallpaper.tags.slice(0, 3).map(tag => (
            <span key={tag} className="text-[10px] bg-stone-800/80 px-2 py-0.5 rounded text-stone-300 uppercase tracking-wider">
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      <div className="absolute top-2 right-2 flex flex-col gap-2 items-end">
        <div className="flex gap-2 items-center opacity-0 group-hover:opacity-100 transition-opacity">
          {isUploaded && onDelete && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                if(confirm('Delete this wallpaper permanently?')) onDelete(wallpaper.id);
              }}
              className="bg-stone-900/80 hover:bg-red-600 p-1.5 rounded-lg text-white backdrop-blur-md transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          )}
          <span className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded">
            {wallpaper.resolution}
          </span>
        </div>
        
        {isSaved && (
          <div className="bg-white/10 backdrop-blur-md p-1.5 rounded-full text-red-500 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 fill-current" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
            </svg>
          </div>
        )}
      </div>
    </div>
  );
};

export default WallpaperCard;
