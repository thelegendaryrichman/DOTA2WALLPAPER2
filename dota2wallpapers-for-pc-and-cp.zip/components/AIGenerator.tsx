
import React, { useState } from 'react';
import { generateDotaWallpaper } from '../services/geminiService';
import { ImageSize } from '../types';

const AIGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<ImageSize>(ImageSize.K1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    setError(null);
    try {
      const imageUrl = await generateDotaWallpaper(prompt, size);
      setResult(imageUrl);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate image. Please check your API key and permissions.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-stone-900/50 rounded-2xl border border-stone-800 p-6">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <span className="text-red-500">◆</span> AI Forge
      </h2>
      <p className="text-stone-400 mb-6">Create high-quality Dota 2 wallpapers using Gemini Nano Banana Pro.</p>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-stone-300 mb-2 uppercase tracking-wide">Prompt</label>
          <textarea 
            className="w-full bg-stone-950 border border-stone-800 rounded-xl p-4 text-stone-200 focus:ring-2 focus:ring-red-500/50 focus:border-red-500 outline-none min-h-[120px]"
            placeholder="e.g. A cinematic shot of Anti-Mage blinking through a mystical forest with purple energy trails, 8k resolution, hyper-realistic..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
        </div>

        <div className="flex flex-col md:flex-row md:items-end gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-stone-300 mb-2 uppercase tracking-wide">Resolution</label>
            <div className="flex gap-2">
              {(Object.keys(ImageSize) as Array<keyof typeof ImageSize>).map((key) => (
                <button
                  key={key}
                  onClick={() => setSize(ImageSize[key])}
                  className={`flex-1 py-2 rounded-lg font-bold border transition-all ${
                    size === ImageSize[key] 
                      ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/20' 
                      : 'bg-stone-950 border-stone-800 text-stone-500 hover:border-stone-700'
                  }`}
                >
                  {ImageSize[key]}
                </button>
              ))}
            </div>
          </div>
          
          <button
            onClick={handleGenerate}
            disabled={loading || !prompt}
            className={`px-8 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
              loading || !prompt 
                ? 'bg-stone-800 text-stone-600 cursor-not-allowed' 
                : 'bg-white text-black hover:bg-stone-200 shadow-xl'
            }`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                Forging...
              </>
            ) : 'Generate Wallpaper'}
          </button>
        </div>

        {error && (
          <div className="p-4 bg-red-950/50 border border-red-900/50 rounded-xl text-red-400 text-sm">
            {error}
          </div>
        )}

        {result && (
          <div className="mt-8">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="text-green-500">✓</span> Masterpiece Created
            </h3>
            <div className="relative group rounded-2xl overflow-hidden border border-stone-700 shadow-2xl">
              <img src={result} alt="Generated result" className="w-full h-auto" />
              <div className="absolute top-4 right-4 flex gap-2">
                <a 
                  href={result} 
                  download="dota-wallpaper.png"
                  className="bg-black/60 hover:bg-black p-3 rounded-full text-white backdrop-blur-md transition-all"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIGenerator;
